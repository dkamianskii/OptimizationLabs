#include "transport_plan.h"

#include <set>

TransportPlan::TransportPlan(VectorSP A, VectorSP B, MatrixSP C) :
  Matrix(C->rows(), C->cols())
{
  Matrix::fill(*this, R_NAN());
}

bool TransportPlan::isDegenerate() const
{ return basisCellQ() < ( m_rows + m_cols - 1 ); }

void TransportPlan::replenish()
{
  throw std::exception("TransportPlan::replenish not implemented");
}

size_t TransportPlan::basisCellQ() const
{
  size_t q = 0;
  for (uint32 i = 1; i <= m_rows; ++i)
    for (uint32 j = 1; j <= m_cols; ++j)
      if (!std::isnan(element(i, j)))
        q++;

  return q;
}
