#include "QR.h"

#include <math.h>
#include <iostream>

void QR(const Matrix& A, Matrix& Q, Matrix& R)
{
  uint32 n = A.cols();
  R = A;
  Q = Matrix::E(n);

  for(uint32 j = 1; j <= n - 1; ++j)
  {
    for(uint32 i = j + 1; i <= n; ++i)
    {
      double x = R.element(j, j),
             y = R.element(i, j);
      double d = sqrt(x * x + y * y);

      if (x == 0 && y == 0)
        continue;

      double c = R.element(j, j) / d;
      double s = R.element(i, j) / d;

      Matrix T = Matrix::E(n);
      T.element(j, j) = c;
      T.element(i, i) = c;
      T.element(j, i) = s;
      T.element(i, j) = -s;

      Q = T * Q;
      
      // R = Q'A = T_n-1,n * ... * T_1,2 * A
      R = T * R;
    }
  }
  // Q = (T_n-1,n * ... * T_1,2)'
  Q = Q.T();
}

void QR_Solve(const Matrix& A, Vector& x, const Vector& b)
{
  uint32 m, n;
  A.dim(m, n);

  if (m != n)
    throw std::logic_error("A.m != A.n");
  if (n != x.dim())
    throw std::logic_error("A.n != x.n");
  if (m != b.dim())
    throw std::logic_error("A.m != b.n");

  Matrix Q(n, n), 
         _R(n, n);
  
  QR(A, Q, _R);

  Vector Qtb(static_cast<Vector>(Q.T() * b));

  // ������ ��������� Rx = Q'b
  for(uint32 i = n; i >= 1; --i)
  {
    R sum = 0.0;
    for(uint32 j = n; j != i; --j)
      sum += _R.element(i, j) * x.element(j);
    x.element(i) = (Qtb.element(i) - sum) / _R.element(i, i);
  }
}

Matrix QR_Inverse(const Matrix& A)
{
  uint32 m, n;
  A.dim(m, n);

  if (m != n)
    throw std::logic_error("m != n");

  Matrix Inv(n, n);
  Matrix Q(n, n),
        _R(n, n);
  QR(A, Q, _R);

  //std::cout << "A" << A;
  //std::cout << "Q" << Q;
  //std::cout << "R" << _R;
  //std::cout << "QR" << Q * _R;

  for (uint32 h = 1; h <= n; ++h) {
    Vector e(n);
    e.element(h) = 1;

    e = static_cast<Vector>(Q.T() * e);
    for (uint32 i = n; i >= 1; --i)
    {
      R sum = 0.0;
      for (uint32 j = n; j != i; --j)
        sum += _R.element(i, j) * Inv.element(h, j);
      R a_hi = (e.element(i) - sum) / _R.element(i, i);
      Inv.element(h, i) = abs(a_hi) < 0.0000000001 ? 0 : a_hi;
    }
  }

  //std::cout << "E" << Inv.T() * A;

  return Inv.T();
}

/*
Matrix_t QR_EigVec(Matrix_t A, double eig)
{
  Matrix_t Q, R;
  uint32 n = A.size();

  Matrix_t b;
  Init_Matrix(b, n, 1);
  A = Matrix_Sum(A, Matrix_Mult(M_E(n), -eig));
  
  QR(A, Q, R);
  b = Matrix_Mult(R, b);

  // ������ ��������� Rx = Q'b
  Matrix_t x;
  Init_Matrix(x, n, 1);

  x[n - 1][0] = 1.0;
  for(uint32 i = 2; i <= n; ++i)
  {
    double sum = 0.0;
    for(uint32 j = 1; j < i; ++j)
      sum += R[n - i][n - j] * x[n - j][0];
    x[n - i][0] = (b[n - i][0] - sum) / R[n - i][n - i];
  }

  return x;
}
*/
