#include "lp_task.h"
#include "base/matrix_util.h"
#include "methods/QR.h"

#include <sstream>
#include <iostream>
#include <set>

LPTask_Canonic::LPTask_Canonic(const MatrixSP& A,
                               const VectorSP& B,
                               const VectorSP& C) :
  m_M(A->rows()),
  m_N(A->cols()),
  m_A(A),
  m_B(B),
  m_C(C),
  m_X(new VectorC(C->dim())),
  m_approxMethod(InitialApprox::Bust),
  m_resolveMethod(ResolveMethod::Simplex)
{
  if (!m_B->isCol())
    throw std::logic_error("B is not column vector");
  if (!m_C->isCol())
    throw std::logic_error("C is not column vector");
  if (m_C->dim() != m_N)
    throw std::logic_error("C->dim() != N");
  if (m_B->dim() != m_M)
    throw std::logic_error("B->dim() != M");
  if (m_X->dim() != m_N)
    throw std::logic_error("X->dim() != M");
}

R LPTask_Canonic::t_func() const
{
  Matrix res = (m_C->T()) * (*m_X);
  return static_cast<R>(static_cast<Vector>(res));
}

bool LPTask_Canonic::checkRestrictions(std::string &) const
{
  return false;
}

std::string LPTask_Canonic::formulation() const
{
  return std::string();
}

std::string LPTask_Canonic::answer() const
{
  std::ostringstream oss;

  oss << "X[N] = " << *m_X << std::endl;
  oss << "F(x) = " << t_func() << std::endl;

  return oss.str();
}

void LPTask_Canonic::resolve()
{
  VectorC X_approx(m_N);
  BitMask basis_approx;

  switch (m_approxMethod)
  {
  case InitialApprox::Bust:
    if (!initialApprox_Bust(X_approx, basis_approx))
      throw std::logic_error("Failed to get initial approximation");
    break;
  default:
    throw std::invalid_argument("no sush approx method");
    break;
  }

  switch (m_resolveMethod)
  {
  case ResolveMethod::Bust:
    resolve_Bust(X_approx, basis_approx);
    break;
  case ResolveMethod::Simplex:
    resolve_Simplex(X_approx, basis_approx);
    break;
  default:
    throw std::invalid_argument("no sush resolve method");
    break;
  }

  //std::cout << *m_A * *m_X << std::endl;
}

const MatrixSP& LPTask_Canonic::A() const
{ return m_A; }

const VectorSP& LPTask_Canonic::B() const
{ return m_B; }

const VectorSP& LPTask_Canonic::C() const
{ return m_C; }

const VectorSP& LPTask_Canonic::X() const
{ return m_X; }

void LPTask_Canonic::setResolveMethod(const ResolveMethod& method)
{ m_resolveMethod = method; }

bool LPTask_Canonic::initialApprox_Bust(VectorC& Xn, BitMask& basis) const
{
  bool validApprox = false;
  Combination L(m_M, m_N);
  Xn = VectorC(m_N);

  //int counter = 0;
  while (!validApprox) {
    MatrixUtil::buildLinIndependent(*m_A, L);
    basis = L.getMask();

    Matrix Amm = MatrixUtil::buildSubMatrix(*m_A, basis);

    VectorC Xm(m_M);
    QR_Solve(Amm, Xm, *m_B);

    // �������� X[M] >= 0
    validApprox = true;
    for (uint32 i = 1; i <= m_M; ++i) {
      if (Xm.element(i) < 0) {
        validApprox = false;
        break;
      }
    }
    
    //counter++;
    //std::cout << counter << std::endl;

    if (!validApprox) {
      if (!L.next())
        break;
      continue;
    }

    uint32 j = 0;
    // ��������� X[M] �� X[N]
    for (uint32 i = 1; i <= m_N; ++i)
      Xn.element(i) = basis[i - 1] ? Xm.element(++j) : 0;
  }

  return validApprox;
}

bool LPTask_Canonic::resolve_Bust(VectorC Xn, BitMask basis) const
{
  Combination L(m_M, m_N);
  if (!L.setMask(basis))
    throw std::invalid_argument("Invalid basis");

  *m_X = Xn;
  R minimum = t_func();

  //int counter = 0;
  while (L.next()) {
    MatrixUtil::buildLinIndependent(*m_A, L);
    basis = L.getMask();

    Matrix Amm = MatrixUtil::buildSubMatrix(*m_A, basis);

    VectorC Xm(m_M);
    QR_Solve(Amm, Xm, *m_B);

    //std::cout << Xm << std::endl << std::endl;

    // �������� X[M] >= 0
    bool validXm = true;
    for (uint32 i = 1; i <= m_M; ++i) {
      if (Xm.element(i) < 0) {
        validXm = false;
        break;
      }
    }
    if (!validXm)
      continue;

    uint32 j = 0;
    // ��������� X[M] �� X[N]
    for (uint32 i = 1; i <= m_N; ++i)
      Xn.element(i) = basis[i - 1] ? Xm.element(++j) : 0;

    R f = (m_C->T()) * (Xn);
    if (f < minimum) {
      minimum = f;
      *m_X = Xn;
    }
    //counter++;
    //std::cout << counter << std::endl;
  }

  return true;
}

bool LPTask_Canonic::resolve_Simplex(VectorC Xk_N, BitMask Nk) const
{
  std::set<BitMask> usedBasises;

  while (true) {
    BitMask Lk = invert(Nk);
    Matrix A_M_Nk = MatrixUtil::buildSubMatrix(*m_A, Nk);
    Matrix B_Nk_M = A_M_Nk.Inverse();
    Vector c_Nk = MatrixUtil::buildSubVector(*m_C, Nk);

    Vector d_N = m_C->T() + (c_Nk.T() * B_Nk_M) * (-1.0 * *m_A);

    std::cout << "d[N]" << d_N.T() << std::endl;

    uint32 jk = 0;
    for (uint32 j = 1; j <= m_N; ++j) {
      if (Lk[j - 1] && d_N.element(j) < 0) {
        jk = j;
        break;
      }
    }

    if (jk == 0) {
      *m_X = Xk_N;
      return true;
    }

    BitMask J(m_N, false);
    J[jk - 1] = true;
    Matrix A_M_jk = MatrixUtil::buildSubMatrix(*m_A, J);
    Vector uk_Nk = static_cast<Vector>(B_Nk_M * A_M_jk);
    Vector uk_N = MatrixUtil::replenishSubVector(uk_Nk, Nk);
    uk_N.element(jk) = -1;

    std::cout << uk_N << std::endl;

#if defined(_DEBUG)
    std::cout << "Xk[N]" << std::endl << Xk_N;
    std::cout << "A[M, Nk]" << std::endl << A_M_Nk << std::endl;
    std::cout << "dim(A[M, Nk])" << (A_M_Nk.isDegenerate() ? "==" : "!=") << "0" << std::endl;
    std::cout << "B[Nk, M]" << std::endl << B_Nk_M << std::endl;
    std::cout << "E" << A_M_Nk * B_Nk_M << std::endl;
    std::cout << "d[N]" << d_N.T() << std::endl;
    std::cout << "uk[N]" << uk_N << std::endl;
#endif

    BitMask I(m_N, false);
    BitMask Nk_plus(m_N, false);
    for (uint32 j = 1; j <= m_N; ++j) {
      if (uk_N.element(j) > 0)
        I[j - 1] = true;
      if (Xk_N.element(j) > 0)
        Nk_plus[j - 1] = true;
    }

    if (power(I) == 0)
      return false;

    bool canRecalcX = true;
    if (power(Nk_plus) != m_M) { // Xk[N] �����������
      for (uint32 i = 1; i <= m_N; ++i)
        if (I[i - 1] && !Nk_plus[i - 1])
          canRecalcX = false;
    }

    if (canRecalcX) { // �������� Xk[N]
      usedBasises.clear();
      R thetta = std::numeric_limits<R>::max();
      uint32 ik = 0;
      for (uint32 i = 1; i <= m_N; ++i) {
        if (I[i - 1]) {
          R thetta_tmp = Xk_N.element(i) / uk_N.element(i);
          if (thetta_tmp < thetta) {
            thetta = thetta_tmp;
            ik = i;
          }
        }
      }

      Xk_N = static_cast<Vector>(Xk_N + (-1.0 * thetta * uk_N));

      Matrix F(m_M, m_M);
      uint32 h = 0;
      for (uint32 j = 1; j <= m_M; ++j) {
        while (!Nk[h])
          h++;
        for (uint32 i = 1; i <= m_M; ++i) {
          if (i == j)
            F.element(i, j) = 1;
          if (h == ik - 1) {
            F.element(i, j) = -uk_Nk.element(i) / uk_N.element(ik);
            if (i == j)
              F.element(i, j) = 1 / uk_N.element(ik);
          }
        }
        h++;
      }

      std::cout << F << std::endl;

      Nk[jk - 1] = true;
      Nk[ik - 1] = false;

      A_M_Nk = MatrixUtil::buildSubMatrix(*m_A, Nk);

      for (uint32 i = 1; i <= m_N; ++i)
        if (Xk_N.element(i) < 0.00001)
          Xk_N.element(i) = 0;

      if (MatrixUtil::buildSubMatrix(*m_A, Nk).isDegenerate()) {
        std::cout << "[INFO]: det(A[M, Nk+1]) == 0" << std::endl;
      }

      B_Nk_M = F * B_Nk_M;
    }
    else { // ����� ������ Nk
      for (uint32 j = 1; j <= m_N; ++j) {
        Nk[j - 1] = false;
        if (Xk_N.element(j) > 0) {
          Nk[j - 1] = true;
        }
        else if (power(Nk) != m_M && Lk[j - 1]) {
          Nk[j - 1] = true;
        }
      }

      Combination C(m_M, m_N);
      C.setMask(Nk);
      do {
        if (!MatrixUtil::buildLinIndependent(*m_A, C))
          throw std::logic_error("Unable to change basis");
        bool fits = true;
        for (uint32 i = 1; i <= m_N; ++i) {
          if ((Nk[i - 1] && !C.getMask()[i - 1]) ||
            (C.getMask()[i - 1] && (!Nk[i - 1] && !Lk[i - 1])))
          {
            fits = false;
            break;
          }
        }
        if (fits && usedBasises.find(Nk) == usedBasises.end()) {
          Nk = C.getMask();
          usedBasises.insert(Nk);

          A_M_Nk = MatrixUtil::buildSubMatrix(*m_A, Nk);
          B_Nk_M = A_M_Nk.Inverse();

          break;
        }
      } while (C.next());
    }
  }
}
