#pragma once

#include <tasks/task.h>
#include <base/matrix.h>
#include <base/combination.h>

class LPTask_Canonic : public ITask {
public:
  enum class InitialApprox {
    Bust
  };

  enum class ResolveMethod {
    Bust,
    Simplex
  };

public:
  LPTask_Canonic(const MatrixSP& A,
                 const VectorSP& B,
                 const VectorSP& C);

  R t_func() const override;
  bool checkRestrictions(std::string&) const override;

  std::string formulation() const override;
  std::string answer() const override;

  void resolve() override;

  const MatrixSP& A() const;
  const VectorSP& B() const;
  const VectorSP& C() const;

  const VectorSP& X() const;

  void setResolveMethod(const ResolveMethod&);

protected:
  uint32 m_M;
  uint32 m_N;

  MatrixSP m_A;
  VectorSP m_B;
  VectorSP m_C;

  VectorSP m_X;

  InitialApprox m_approxMethod;
  ResolveMethod m_resolveMethod;

private:
  bool initialApprox_Bust(VectorC& Xn, BitMask& basis) const;

  bool resolve_Bust(VectorC Xn, BitMask basis) const;
  bool resolve_Simplex(VectorC Xk, BitMask Nk) const;

};
