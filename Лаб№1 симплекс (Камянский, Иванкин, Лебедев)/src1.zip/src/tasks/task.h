#pragma once

#include "base/defines.h"
#include <string>

class ITask {
public:
  virtual R t_func() const = 0;
  virtual bool checkRestrictions(std::string&) const = 0;

  virtual std::string formulation() const = 0;
  virtual std::string answer() const = 0;

  virtual void resolve() = 0;

};