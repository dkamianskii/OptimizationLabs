#include <iostream>
#include <iomanip>

#include "base/matrix.h"
#include "base/matrix_util.h"
#include "tasks/simplex/lp_task.h"
#include "methods/QR.h"

#define a(i, j) A->element(i, j)
#define b(i) B->element(i)
#define c(i) C->element(i)

//#define EPS -0.03

void TASK8(LPTask_Canonic::ResolveMethod resolveMethod)
{
  uint32 M = 3,
         N = 7;

  MatrixSP A(new Matrix(M, N));
  VectorSP B(new VectorC(M));
  VectorSP C(new VectorC(N));

  a(1, 1) = 1; a(1, 2) = 1; a(1, 3) = 1; a(1, 4) = 1; a(1, 5) = 1; a(1, 6) = 0; a(1, 7) = 0;  b(1) = 1;
  a(2, 1) = 1; a(2, 2) = 3; a(2, 3) = 5; a(2, 4) = 3; a(2, 5) = 2; a(2, 6) = -1; a(2, 7) = 0;  b(2) = 2;
  a(3, 1) = 8; a(3, 2) = 6; a(3, 3) = 1; a(3, 4) = 1; a(3, 5) = 1; a(3, 6) = 0;  a(3, 7) = 1;  b(3) = 4;


  c(1) = 4;    c(2) = 4.5;    c(3) = 5.8;  c(4) = 6;  c(5) = 7.5;  c(6) = 0;  c(7) = 0;

  
//    c(1) += EPS;
    

  LPTask_Canonic task(A, B, C);

  task.setResolveMethod(resolveMethod);
  task.resolve();

//  std::cout << "c[1] + " << EPS << std::endl << std::endl;

  std::cout << task.answer() << std::endl;
}

void TASK8_DUAL(LPTask_Canonic::ResolveMethod resolveMethod)
{
  uint32 M = 5,
         N = 8;

  VectorSP B(new VectorC(M));
  VectorSP C(new VectorC(N));

  MatrixSP A(new Matrix(M, N));
  a(1, 1) = 1; a(1, 2) = 1; a(1, 3) = -8;
  a(2, 1) = 1; a(2, 2) = 3; a(2, 3) = -6;
  a(3, 1) = 1; a(3, 2) = 5; a(3, 3) = -1;
  a(4, 1) = 1; a(4, 2) = 3; a(4, 3) = -1;
  a(5, 1) = 1; a(5, 2) = 2; a(5, 3) = -1;


  for (uint32 i = 1; i <= M; ++i)
    a(i, 3 + i) = 1;

  std::cout << "A" << *A;

  b(1) = 4;
  b(2) = 4.5;
  b(3) = 5.8;
  b(4) = 6;
  b(5) = 7.5;

  c(1) = 1;
  c(2) = 2;
  c(3) = -4;

  *C = (*C * (-1.0));

  LPTask_Canonic task(A, B, C);

  task.setResolveMethod(resolveMethod);
  task.resolve();

  *task.C() = (*task.C() * (-1.0));

  std::cout << task.answer() << std::endl;
}

int main(void)
{ 
  int execResult = 0;

  std::cout << std::setprecision(2);

  bool execute = true;

  do {
    char menu;

    std::cout << "1. Task 8 (Simplex)" << std::endl;
    std::cout << "2. Task 8 dual (Simplex)" << std::endl;
    std::cout << std::endl;
    std::cout << "q. Quit" << std::endl;
    std::cout << std::endl;

    std::cout << "Choose variant: ";
    std::cin >> menu;

    switch (menu) {
    case '1':
      TASK8(LPTask_Canonic::ResolveMethod::Simplex);
      break;
    case '2':
      TASK8_DUAL(LPTask_Canonic::ResolveMethod::Simplex);
      break;
    case 'q':
      execute = false;
      break;
    default:
      std::cout << "Invalid variant" << std::endl;
      break;
    }
  } while (execute);
  
  return execResult;
}
