#include "combination.h"
#include <algorithm>

Combination::Combination(uint32 m, uint32 n) :
  m_m(m),
  m_n(n),
  m_mask()
{
  makeFirst();
}

bool Combination::isValid() const
{
  if (m_mask.size() != m_n)
    return false;
  if (power(m_mask) != m_m)
    return false;

  return true;
}

void Combination::makeFirst()
{
  m_mask.clear();
  m_mask.resize(m_n, false);
  std::fill(m_mask.begin(), m_mask.begin() + m_m, true);
}

void Combination::makeLast()
{
  m_mask.clear();
  m_mask.resize(m_n, false);
  std::fill(m_mask.end() - m_m, m_mask.end(), true);
}

bool Combination::next()
{
  for (uint32 i = 0; i < m_n - m_m; ++i) {
    if (m_mask[i]) {
      std::prev_permutation(m_mask.begin(), m_mask.end());
      return true;
    }
  }

  return false;  
}

bool Combination::prev()
{
  for (uint32 i = 0; i < m_m; ++i) {
    if (!m_mask[i]) {
      std::next_permutation(m_mask.begin(), m_mask.end());
      return true;
    }
  }

  return false;
}

const BitMask& Combination::getMask() const
{
  return m_mask;
}

bool Combination::setMask(const BitMask& data)
{
  m_mask = data;
  if (isValid())
    return true;

  m_mask.clear();
  return false;
}

bool Combination::setMask(const BitMask&& data)
{
  m_mask = std::move(data);
  if (isValid())
    return true;

  m_mask.clear();
  return false;
}

uint32 Combination::getM() const
{
  return m_m;
}

uint32 Combination::getN() const
{
  return m_n;
}
