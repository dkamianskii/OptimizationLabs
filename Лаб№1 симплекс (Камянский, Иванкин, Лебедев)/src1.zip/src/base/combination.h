#pragma once
#include "base/defines.h"
#include "base/bitmask.h"

class Combination {
public:
  Combination(uint32 m, uint32 n);

  bool isValid() const;

  void makeFirst();
  void makeLast();

  bool next();
  bool prev();

  const BitMask& getMask() const;
  bool setMask(const BitMask&);
  bool setMask(const BitMask&&);

  uint32 getM() const;
  uint32 getN() const;

protected:
  uint32 m_m;
  uint32 m_n;
  BitMask m_mask;

};
