#include "matrix.h"
#include "methods/QR.h"

#include <cstring>
#include <iostream>

Matrix::Matrix(uint32 m, uint32 n) :
  m_rows(m),
  m_cols(n),
  m_array(new R[(size_t)m * (size_t)n])
{ 
  _CHECK_DIM();
  fill(*this, 0);
}

Matrix::Matrix(const MatrixElIndex& size) :
  Matrix(size.first, size.second)
{ }

Matrix::Matrix(const Matrix& that) :
  m_rows(that.rows()),
  m_cols(that.cols()),
  m_array(new R[(size_t)m_rows * (size_t)m_cols])
{
  size_t array_size = (size_t)m_rows * (size_t)m_cols;
  std::memcpy(this->m_array, that.m_array, array_size * sizeof(R));
}

Matrix::~Matrix()
{
  delete m_array;
}

void Matrix::get(uint32 i, uint32 j, R& val) const
{ val = m_array[_INDEX(i, j)]; }

void Matrix::set(uint32 i, uint32 j, const R& val)
{ m_array[_INDEX(i, j)] = val; }

R& Matrix::element(uint32 i, uint32 j)
{ return m_array[_INDEX(i, j)]; }

const R& Matrix::element(uint32 i, uint32 j) const
{ return m_array[_INDEX(i, j)]; }

R& Matrix::element(MatrixElIndex index)
{ return element(index.first, index.second); }

const R& Matrix::element(MatrixElIndex index) const
{ return element(index.first, index.second); }

void Matrix::dim(uint32 &m, uint32 &n) const
{ 
  m = m_rows; 
  n = m_cols; 
}

void Matrix::dim(MatrixElIndex& size) const
{ dim(size.first, size.second); }

uint32 Matrix::rows() const
{ return m_rows; }

uint32 Matrix::cols() const
{ return m_cols; }

Matrix Matrix::T() const
{
  uint32 m, n;
  this->dim(n, m);
  Matrix that(m, n);

  for (uint32 i = 1; i <= m; ++i)
    for (uint32 j = 1; j <= n; ++j)
      that.element(i, j) = this->element(j, i);

  return that;
}

Matrix Matrix::Inverse() const
{
  return QR_Inverse(*this);
}

Matrix Matrix::operator=(const Matrix& that)
{
  m_rows = that.m_rows;
  m_cols = that.m_cols;

  delete m_array;
  m_array = new R[(size_t)m_rows * (size_t)m_cols];

  std::memcpy(this->m_array, that.m_array, 
              sizeof(R) * m_rows * m_cols);

  return *this;
}

Matrix::operator Vector() const
{
  if (rows() != 1 && cols() != 1)
    throw std::logic_error("This matrix is not a vector");
  
  bool isCol = cols() == 1;
  uint32 n = isCol ? rows() : cols();
  Vector a(n, isCol);

  MatrixElIndex index = std::make_pair(1, 1);
  for (uint32* i = isCol ? &index.first : &index.second; *i <= n; ++*i)
    a.element(*i) = this->element(index);

  return a;
}

Matrix::operator VectorSP() const
{
  return VectorSP(new Vector(this->operator Vector()));
}

Matrix::operator R() const
{
  return (R)(operator Vector());
}

Matrix Matrix::E(uint32 n)
{
  Matrix e(n, n);
  for (uint32 i = 1; i <= n; ++i)
    e.element(i, i) = 1;

  return e;
}

bool Matrix::isDegenerate() const
{
  if (m_rows != m_cols)
    throw std::logic_error("m != n");

  Matrix _Q(m_rows, m_cols),
         _R(m_rows, m_cols);
  QR(*this, _Q, _R);

  //std::cout << *this << std::endl;
  //std::cout << _Q * _R << std::endl;

  //std::cout << _R << std::endl;

  for (uint32 i = 1; i <= m_rows; ++i) {
    R d = _R.element(i, i);

    if (d != d) // d == NaN
      return true;
    if (d == 0)
      return true;
  }

  return false;
}

Vector Matrix::getRow(uint32 i) const
{
  if (i > m_rows)
    throw std::out_of_range("i > m");

  VectorR a(m_cols);
  for (uint32 j = 1; j <= m_cols; ++j)
    a.element(j) = this->element(i, j);

  return a;
}

Vector Matrix::getCol(uint32 j) const
{
  if (j > m_cols)
    throw std::out_of_range("j > n");

  VectorC a(m_rows);
  for (uint32 i = 1; i <= m_cols; ++i)
    a.element(i) = this->element(i, j);

  return a;
}

void Matrix::append(const Vector& that)
{
  MatrixElIndex size;
  dim(size);

  uint32 *mod  =  that.isCol() ? &size.first : &size.second,
         *nmod = !that.isCol() ? &size.first : &size.second;
  *mod += 1;

  if (*nmod == 0)
    *nmod = that.dim();

  if (*nmod != that.dim())
    throw std::logic_error("Invalid sizes");

  Matrix n_this(size);
  for (uint32 i = 1; i <= m_rows; ++i)
    for (uint32 j = 1; j <= m_cols; ++j)
      n_this.element(i, j) = this->element(i, j);

  uint32 n = *nmod;
  for (*nmod = 1; *nmod <= n; ++*nmod)
    n_this.element(size) = that.element(*nmod);

  *this = n_this;
}

void Matrix::fill(Matrix& M, const R& val)
{
  size_t capacity = M.m_cols * M.m_rows;
  for (size_t i = 0; i < capacity; ++i)
    M.m_array[i] = val;
}

size_t Matrix::_INDEX(uint32 i, uint32 j) const
{ 
  _CHECK_RANGE(i, j);

  i = i - 1;
  j = j - 1;
  return (size_t)i * (size_t)m_cols + (size_t)j;
}

void Matrix::_CHECK_RANGE(uint32 i, uint32 j) const
{
  if (i == 0 || i > m_rows)
    throw std::out_of_range("i out of range");
  if (j == 0 || j > m_cols)
    throw std::out_of_range("j out of range");
}

void Matrix::_CHECK_DIM() const
{
  if (m_rows == 0)
    throw std::logic_error("rows quantity is 0");
  if (m_cols == 0)
    throw std::logic_error("cols quantity is 0");
}



Vector::Vector(uint32 n, bool col) :
  Matrix(col ? n : 1,
         col ? 1 : n),
  m_col(col)
{ }

Vector::Vector(const Vector& that) :
  Matrix(that),
  m_col(that.m_col)
{
}

void Vector::get(uint32 i, R& val) const
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  Matrix::get(matrix_i, matrix_j, val);
}

void Vector::set(uint32 i, const R& val)
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  Matrix::set(matrix_i, matrix_j, val);
}

R& Vector::element(uint32 i)
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  return Matrix::element(matrix_i, matrix_j);
}

const R& Vector::element(uint32 i) const
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  return Matrix::element(matrix_i, matrix_j);
}

void Vector::dim(uint32& n) const
{
  uint32 matrix_m, matrix_n;
  Matrix::dim(matrix_m, matrix_n);

  n = m_col ? matrix_m : matrix_n;
}

const uint32& Vector::dim() const
{ return m_col ? m_rows : m_cols; }

bool Vector::isCol() const
{ return m_col; }

R Vector::sum() const
{
  R _sum = 0;
  uint32 n = dim();
  for (uint32 i = 1; i <= n; ++i)
    _sum += element(i);
  return _sum;
}

Vector Vector::operator=(const Vector& that)
{
  Matrix::operator=(that);
  this->m_col = that.m_col;
  return *this;
}

Vector::operator R() const
{
  if (dim() != 1)
    throw std::logic_error("This is not a single value vector");

  return element(1);
}

void Vector::matrixIndices(uint32 i, uint32& m_i, uint32& m_j) const
{
  m_i = m_col ? i : 1;
  m_j = m_col ? 1 : i;
}

std::ostream& operator<<(std::ostream& out_stream, const Matrix& matrix)
{
  uint32 rows = matrix.rows(), 
         cols = matrix.cols();
  for (uint32 i = 1; i <= rows; ++i) {
    for (uint32 j = 1; j <= cols; ++j)
      out_stream << "\t" << matrix.element(i, j);
    out_stream << std::endl;
  }

  return out_stream;
}

Matrix operator*(const R& l, const Matrix& r)
{
  uint32 m, n;
  r.dim(m, n);
  Matrix a(m, n);

  for (uint32 i = 1; i <= m; ++i)
    for (uint32 j = 1; j <= n; ++j)
      a.element(i, j) = l * r.element(i, j);
      
  return a;
}

Matrix operator*(const Matrix& l, const R& r)
{ return r * l; }

Matrix operator+(const Matrix& l, const Matrix& r)
{
  if (l.rows() != r.rows())
    throw std::logic_error("l.rows() != r.rows()");
  if (l.cols() != r.cols())
    throw std::logic_error("l.cols() != r.cols()");

  uint32 m, n;
  l.dim(m, n);
  Matrix a(m, n);

  for (uint32 i = 1; i <= m; ++i)
    for (uint32 j = 1; j <= n; ++j)
      a.element(i, j) = l.element(i, j) + r.element(i, j);

  return a;
}

Matrix operator*(const Matrix& l, const Matrix& r)
{
  if (l.cols() != r.rows())
    throw std::logic_error("l.cols() != r.rows()");

  uint32 m = l.rows(),
         n = r.cols();
  Matrix a(m, n);

  uint32 h_max = l.cols();
  for (uint32 i = 1; i <= m; ++i)
    for (uint32 j = 1; j <= n; ++j) {
      R a_ij = 0;
      for (uint32 h = 1; h <= h_max; ++h)
        a_ij += l.element(i, h) * r.element(h, j);
      a.element(i, j) = abs(a_ij) < 0.0000000001 ? 0 : a_ij;
    }

  return a;
}

std::ostream& operator<<(std::ostream& out_stream, const Vector& vector)
{
  return operator<<(out_stream, *(Matrix*)(&vector));
}
