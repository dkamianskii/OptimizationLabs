#pragma once
#include <vector>

using BitMask = std::vector<bool>;

size_t power(const BitMask&);
BitMask invert(const BitMask&);