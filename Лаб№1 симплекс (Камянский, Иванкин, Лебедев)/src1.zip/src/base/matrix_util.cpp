#include "matrix_util.h"
#include <numeric>
#include <iostream>

/*
bool MatrixUtil::isLinIndependent(const VectorSystem& linIndSystem, const Vector& newVec)
{
  if (linIndSystem.empty())
    return true;

  uint32 m = linIndSystem[0].dim(),
         n = linIndSystem.size();

  if (m < n)
    throw std::logic_error("linIndSystem is not linear independent!");

  if (newVec.dim() != m)
    throw std::logic_error("Invalid newVec size");

  // linIndSystem �������� n ������ �����
  if (m == n)
    return false;
  
  Matrix A_nn(n, n);
  Vector b_n(n); 
  {
    uint32 j = 1;
    for (auto it = linIndSystem.begin(); it != linIndSystem.end(); ++it, ++j) {
      if (it->dim() != m)
        throw std::logic_error("invalid linIndSystem m size");

      for (uint32 i = 1; i <= n; ++i) {
        A_nn.element(i, j) = it->element(i);
        b_n.element(i) = newVec.element(i);
      }
    }
  }
  A_nn = A_nn.T();

  for (uint32 i = n + 1; i <= m; ++i) {
    Vector A_1n(1, n); {
      uint32 j = 1;
      for (auto it = linIndSystem.begin(); it != linIndSystem.end(); ++it, ++j)
        A_1n.element(j) = it->elemnt(i);
    }
    R b_1 = newVec.element(i);
    Vector x(n);

    QR_Solve(A_nn, x, A_1n);
    if (b_1 - static_cast<R>(b_n * x) == 0)
      return false;
  }

  return true;
}
*/

bool MatrixUtil::buildLinIndependent(const Matrix& A, Combination& C)
{
  if (C.getMask().size() == 0)
    return false;
  do {
    if (C.getMask().size() == 0)
      return false;
    Matrix A_m = buildSubMatrix(A, C.getMask());
    if (!A_m.isDegenerate())
      return true;
  } while (C.next());

  return false;
}

bool MatrixUtil::replenishLinIndependent(const Matrix& A, BitMask& baseMask, const BitMask& extraMask)
{
  Combination C(A.rows(), A.cols());
  do {
    BitMask currentMask = C.getMask();
    bool fits = true;
    for (uint32 i = 1; i <= A.cols(); ++i) {
      if (  ( baseMask[i - 1]    && !currentMask[i - 1] ) ||
            ( currentMask[i - 1] && (!baseMask[i - 1] && !extraMask[i - 1]) )  ) 
      {
        fits = false;
        break;
      }
    }

    if (!fits)
      continue;

    Matrix A_m = buildSubMatrix(A, currentMask);
    if (!A_m.isDegenerate()) {
      baseMask = C.getMask();
      return true;
    }
  } while (C.next());

  return false;
}

Matrix MatrixUtil::buildSubMatrix(const Matrix &A, const BitMask& mask)
{
  uint32 m = A.rows(),
         n = std::accumulate(mask.begin(), mask.end(), 0);
  
  Matrix sA(m, n);

  uint32 j = 1;
  for (auto bit = mask.begin(); bit != mask.end(); ++bit) {
    if (!*bit)
      continue;
    uint32 c = bit - mask.begin() + 1;
    for (uint32 i = 1; i <= m; ++i)
      sA.element(i, j) = A.element(i, c);
    ++j;
  }

  return sA;
}

Matrix MatrixUtil::replenishSubMatrix(const Matrix& sA, const BitMask& mask)
{
  uint32 n = mask.size();
  Matrix A(mask.size(), mask.size());

  uint32 h = 0;
  for (uint32 i = 1; i <= n; ++i) {
    if (mask[i - 1]) {
      h += 1;
      for (uint32 j = 1; j <= n; ++j)
        A.element(i, j) = sA.element(h, j);
    }
  }

  return A;
}

Vector MatrixUtil::buildSubVector(const Vector& V, const BitMask& mask)
{
  uint32 n = std::accumulate(mask.begin(), mask.end(), 0);
  Vector sV(n, V.isCol());

  uint32 j = 1;
  for (auto bit = mask.begin(); bit != mask.end(); ++bit) {
    if (!*bit)
      continue;
    uint32 c = bit - mask.begin() + 1;
    sV.element(j) = V.element(c);
    ++j;
  }

  return sV;
}

Vector MatrixUtil::replenishSubVector(const Vector& sV, const BitMask& mask)
{
  uint32 n = mask.size();
  Vector V(n, sV.isCol());

  uint32 h = 0;
  for (uint32 i = 1; i <= n; ++i) {
    if (mask[i - 1]) {
      h += 1;
      V.element(i) = sV.element(h);
    }
  }

  return V;
}
