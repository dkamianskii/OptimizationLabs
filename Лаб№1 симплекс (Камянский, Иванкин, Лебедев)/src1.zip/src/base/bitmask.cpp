#include "bitmask.h"

size_t power(const BitMask& mask)
{
  size_t pow = 0;
  for (const bool& b : mask)
    if (b)
      pow += 1;

  return pow;
}

BitMask invert(const BitMask& straight)
{
  size_t size = straight.size();
  BitMask inverted(size);

  for (size_t i = 0; i < size; ++i)
    inverted[i] = !straight[i];

  return inverted;
}