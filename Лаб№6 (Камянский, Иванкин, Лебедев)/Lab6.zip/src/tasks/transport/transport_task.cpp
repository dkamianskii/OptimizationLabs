#include "transport_task.h"

#include <sstream>

TransportTask::TransportTask(VectorSP A, VectorSP B, MatrixSP C) :
  ITask(),
  m_A(A),
  m_B(B),
  m_C(C),
  m_X()
{ 
  /* ���������� ����� ���������� */
#if defined(_DEBUG_TTASK)
  std::cout << "A" << std::endl;
  std::cout << *m_A;

  std::cout << "B" << std::endl;
  std::cout << *m_B;

  std::cout << "C" << std::endl;
  std::cout << *m_C;
#endif

  _CHECK_EXIST();
  _CHECK_DIM();
}

R TransportTask::t_func() const
{
  uint32 X_m, X_n;
  m_X->dim(X_m, X_n);

  R sum = 0;
  for (uint32 i = 1; i <= X_m; ++i)
    for (uint32 j = 1; j <= X_n; ++j)
      if (!std::isnan(m_X->element(i, j)))
        sum += m_X->element(i, j) * m_C->element(i, j);

  return sum;
}

bool TransportTask::checkRestrictions(std::string& errorMessage) const
{
  errorMessage.clear();

  uint32 X_m, X_n;
  m_X->dim(X_m, X_n);

  for (uint32 i = 1; i <= X_m; ++i)
    for (uint32 j = 1; j <= X_n; ++j)
      if (!std::isnan(m_X->element(i, j)))
        if (m_X->element(i, j) < 0) {
          errorMessage = "X[" + std::to_string(i) + ", " + std::to_string(j) + "] < 0";
          return false;
        }
          

  for (uint32 i = 1; i <= X_m; ++i) {
    R sum = 0;
    for (uint32 j = 1; j <= X_n; ++j)
      if (!std::isnan(m_X->element(i, j)))
        sum += m_X->element(i, j);

    if (sum > m_A->element(i)) {
      errorMessage = "sum(X[ " + std::to_string(i) + ", j = 1.." + std::to_string(X_n) + " ]) > A[" + std::to_string(i) + "]";
      return false;
    }
  }

  for (uint32 j = 1; j <= X_n; ++j) {
    R sum = 0;
    for (uint32 i = 1; i <= X_m; ++i)
      if (!std::isnan(m_X->element(i, j)))
        sum += m_X->element(i, j);

    if (sum > m_B->element(j)) {
      errorMessage = "sum(X[ i = 1.." + std::to_string(X_m) + ", " + std::to_string(j) + " ]) > B[" + std::to_string(j) + "]";
      return false;
    } 
  }

  return true;
}

std::string TransportTask::formulation() const
{
  std::ostringstream oss;

  uint32 m = m_A->dim(), 
         n = m_B->dim();

  oss << "  \t";
  for (uint32 j = 1; j <= n; ++j)
    oss << "B" << j << "\t";
  oss << std::endl;

  for (uint32 i = 1; i <= m; ++i) {
    oss << "A" << i << "\t";
    for (uint32 j = 1; j <= n; ++j)
      oss << m_C->element(i, j) << "\t";
    oss << m_A->element(i) << std::endl;
  }

  oss << "  \t";
  for (uint32 j = 1; j <= n; ++j)
    oss << m_B->element(j) << "\t";
  oss << std::endl;

  return oss.str();
}

std::string TransportTask::answer() const
{
  std::ostringstream oss;
  
  uint32 m = m_A->dim(),
    n = m_B->dim();

  oss << "  \t";
  for (uint32 j = 1; j <= n; ++j)
    oss << "B" << j << "\t";
  oss << std::endl;

  for (uint32 i = 1; i <= m; ++i) {
    oss << "A" << i << "\t";
    for (uint32 j = 1; j <= n; ++j)
      oss << m_X->element(i, j) << "\t";
    oss << m_A->element(i) << std::endl;
  }

  oss << "  \t";
  for (uint32 j = 1; j <= n; ++j)
    oss << m_B->element(j) << "\t";
  oss << std::endl;

  return oss.str();
}

const VectorSP& TransportTask::A() const
{ return m_A; }

const VectorSP& TransportTask::B() const
{ return m_B; }

const MatrixSP& TransportTask::C() const
{ return m_C; }

const TransportPlanSP& TransportTask::X() const
{ return m_X; }

bool TransportTask::isClosed() const
{
  uint32 A_n, B_n;
  m_A->dim(A_n);
  m_B->dim(B_n);

  R A_sum = 0;
  for (uint32 i = 1; i <= A_n; ++i)
    A_sum += m_A->element(i);

  R B_sum = 0;
  for (uint32 i = 1; i <= B_n; ++i)
    B_sum += m_B->element(i);

  return (A_sum == B_sum);
}

void TransportTask::makeClosed()
{
  throw std::exception("TransportTask::makeClosed not implemented");
}

void TransportTask::_CHECK_EXIST() const
{
  if (!m_A)
    throw std::invalid_argument("A is nullptr");
  if (!m_B)
    throw std::invalid_argument("B is nullptr");
  if (!m_C)
    throw std::invalid_argument("C is nullptr");
}

void TransportTask::_CHECK_DIM() const
{
  uint32 A_n, B_n, C_m, C_n;
  m_A->dim(A_n);
  m_B->dim(B_n);
  m_C->dim(C_m, C_n);

  if (C_m != A_n)
    throw std::invalid_argument("C rows quantity must be equal to A size");
  if (C_n != B_n)
    throw std::invalid_argument("C cols quantity must be equal to B size");
}
