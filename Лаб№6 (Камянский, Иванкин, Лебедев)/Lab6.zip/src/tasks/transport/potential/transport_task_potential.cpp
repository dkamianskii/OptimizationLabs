#include "transport_task_potential.h"
#include "tasks/transport/tp_double_preference.h"

TransportTask_Potential::TransportTask_Potential(VectorSP A, VectorSP B, MatrixSP C) :
  TransportTask(A, B, C),
  m_U(),
  m_V()
{
  m_U = VectorSP(new Vector(m_A->dim()));
  m_V = VectorSP(new Vector(m_B->dim()));
}

void TransportTask_Potential::resolve()
{
  /* �������� �� ���������� */
  if (!isClosed())
    makeClosed();

  /* ��������� ����������� ������� �������� ������������ */
  m_X = TransportPlanSP(new TransportPlan_DP(m_A, m_B, m_C));

  std::cout << "X" << std::endl;
  std::cout << *m_X << std::endl;

#if defined(_DEBUG_POTENTIAL)
  std::cout << "X" << std::endl;
  std::cout << *m_X << std::endl;
#endif

  /* �������� �� ������������� */
  if (m_X->isDegenerate())
    m_X->replenish();

  /* ���������� �������� ���������� ����������� */
#if defined(_DEBUG_POTENTIAL)
  std::cout << "Z = " << t_func() << std::endl;

  std::string errorMessage;
  if (!checkRestrictions(errorMessage))
    std::cout << "[ERROR] Restriction broken: " << errorMessage << std::endl;
#endif

  /* ���������� ����������� */
  ReconPotentials();

  MatrixElIndex minimal_dif;
  while (!isOptimal(minimal_dif))
    redistrTransportPlan(minimal_dif);
}

void TransportTask_Potential::ReconPotentials()
{
  Matrix::fill((*m_U).operator Matrix&(), R_NAN());
  Matrix::fill((*m_V).operator Matrix&(), R_NAN());

  /* ����������� ���������� ����������� */
  setU_el(1, 0, 0);

#if defined(_DEBUG_POTENTIAL)
  std::cout << "U" << std::endl;
  std::cout << *m_U << std::endl;

  std::cout << "V" << std::endl;
  std::cout << *m_V << std::endl;
#endif
}

bool TransportTask_Potential::isOptimal(MatrixElIndex& minimal) const
{
  uint32 m = m_C->rows(),
         n = m_C->cols();

  R min = 0;

  for (uint32 i = 1; i <= m; ++i) {
    for (uint32 j = 1; j <= n; ++j) {
      R dC = m_C->element(i, j) - (m_U->element(i) + m_V->element(j));
      if (dC < min) {
        min = dC;
        minimal = MatrixElIndex(i, j);
      }
    }
  }
    
  return min == 0;
}

void TransportTask_Potential::redistrTransportPlan(const MatrixElIndex& minimal_dif)
{
  std::vector<MatrixElIndex> cycle;
  buildRedistCycle(minimal_dif, cycle);

  MatrixElIndex minimal_inCycle = cycle[1];
  R minimal_val_inCycle         = m_X->element(minimal_inCycle);

  for (size_t i = 1; i < cycle.size(); i += 2) {
    if (m_X->element(cycle[i]) < minimal_val_inCycle) {
      minimal_inCycle     = cycle[i];
      minimal_val_inCycle = m_X->element(minimal_inCycle);
    }
  }

  m_X->element(minimal_dif) = 0;

  for (size_t i = 0; i < cycle.size(); ++i)
      m_X->element(cycle[i]) += (i % 2 ? -1.0 : 1.0) * minimal_val_inCycle;

  m_X->element(minimal_inCycle) = R_NAN();

#if defined(_DEBUG_POTENTIAL)
  std::cout << "X" << std::endl;
  std::cout << *m_X;
#endif

  /* ���������� ����������� */
  ReconPotentials();
}

void TransportTask_Potential::setU_el(uint32 i, uint32 j, const R& val)
{
  m_U->element(i) = val;

  uint32 n = m_V->dim();

  for (uint32 h = 1; h <= n; ++h) {
    /* Prevent endless recursion */
    if (h == j)
      continue;
    if (!std::isnan(m_X->element(i, h))) {
      R V = m_C->element(i, h) - val;
      /* Join deeper recursion layer */
      setV_el(i, h, V);
    }
  }
}

void TransportTask_Potential::setV_el(uint32 i, uint32 j, const R& val)
{
  m_V->element(j) = val;

  uint32 m = m_U->dim();

  for (uint32 h = 1; h <= m; ++h) {
    /* Prevent endless recursion */
    if (h == i)
      continue;
    if (!std::isnan(m_X->element(h, j))) {
      R U = m_C->element(h, j) - val;
      /* Join deeper recursion layer */
      setU_el(h, j, U);
    }
  }
}

void TransportTask_Potential::buildRedistCycle(const MatrixElIndex& start, 
                                               std::vector<MatrixElIndex>& cycle) const
{
  cycle.clear();
  cycle.push_back(start);

  if (!lookH(cycle))
    throw std::logic_error("TransportTask_Potential::buildRedistCycle failed");
}

bool TransportTask_Potential::lookH(std::vector<MatrixElIndex>& cycle) const
{
  MatrixElIndex start = cycle.back();
  
  uint32 n = m_X->cols();
  uint32 i = start.first;
  for (uint32 j = 1; j <= n; ++j) {
    if (start.second == j)
      continue;

    MatrixElIndex index(i, j);
    if (!std::isnan(m_X->element(index))) {
      cycle.push_back(index);

      if (lookV(cycle))
        return true;
      else
        cycle.pop_back();
    }
  }

  return false;
}

bool TransportTask_Potential::lookV(std::vector<MatrixElIndex>& cycle) const
{
  MatrixElIndex start = cycle.back();

  uint32 m = m_X->rows();
  uint32 j = start.second;
  for (uint32 i = 1; i <= m; ++i) {
    if (start.first == i)
      continue;

    MatrixElIndex index(i, j);
    if (cycle.front() == index) {
      return true;
    }

    if (!std::isnan(m_X->element(index))) {
      cycle.push_back(index);

      if (lookH(cycle))
        return true;
      else
        cycle.pop_back();
    }
  }

  return false;
}
