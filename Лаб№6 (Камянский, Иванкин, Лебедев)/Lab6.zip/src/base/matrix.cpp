#include "matrix.h"

#include <cstring>

Matrix::Matrix(uint32 m, uint32 n) :
  m_rows(m),
  m_cols(n),
  m_array(new R[(size_t)m * (size_t)n])
{ 
  _CHECK_DIM();
  fill(*this, 0);
}

Matrix::Matrix(const Matrix& that) :
  m_rows(that.rows()),
  m_cols(that.cols()),
  m_array(new R[(size_t)m_rows * (size_t)m_cols])
{
  size_t array_size = (size_t)m_rows * (size_t)m_cols;
  std::memcpy(this->m_array, that.m_array, array_size * sizeof(R));
}

Matrix::~Matrix()
{
  delete m_array;
}

void Matrix::get(uint32 i, uint32 j, R& val) const
{ val = m_array[_INDEX(i, j)]; }

void Matrix::set(uint32 i, uint32 j, const R& val)
{ m_array[_INDEX(i, j)] = val; }

R& Matrix::element(uint32 i, uint32 j)
{ return m_array[_INDEX(i, j)]; }

const R& Matrix::element(uint32 i, uint32 j) const
{ return m_array[_INDEX(i, j)]; }

R& Matrix::element(MatrixElIndex index)
{ return element(index.first, index.second); }

const R& Matrix::element(MatrixElIndex index) const
{ return element(index.first, index.second); }

void Matrix::dim(uint32 &m, uint32 &n) const
{ 
  m = m_rows; 
  n = m_cols; 
}

uint32 Matrix::rows() const
{ return m_rows; }

uint32 Matrix::cols() const
{ return m_cols; }

void Matrix::fill(Matrix& M, const R& val)
{
  size_t capacity = M.m_cols * M.m_rows;
  for (size_t i = 0; i < capacity; ++i)
    M.m_array[i] = val;
}

size_t Matrix::_INDEX(uint32 i, uint32 j) const
{ 
  _CHECK_RANGE(i, j);

  i = i - 1;
  j = j - 1;
  return (size_t)i * (size_t)m_cols + (size_t)j;
}

void Matrix::_CHECK_RANGE(uint32 i, uint32 j) const
{
  if (i == 0 || i > m_rows)
    throw std::out_of_range("i out of range");
  if (j == 0 || j > m_cols)
    throw std::out_of_range("j out of range");
}

void Matrix::_CHECK_DIM() const
{
  if (m_rows == 0)
    throw std::logic_error("rows quantity is 0");
  if (m_cols == 0)
    throw std::logic_error("cols quantity is 0");
}



Vector::Vector(uint32 n, bool col) :
  Matrix(col ? n : 1,
         col ? 1 : n),
  m_col(col)
{ }

Vector::Vector(const Vector& that) :
  Matrix(that),
  m_col(that.m_col)
{
}

void Vector::get(uint32 i, R& val) const
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  Matrix::get(matrix_i, matrix_j, val);
}

void Vector::set(uint32 i, const R& val)
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  Matrix::set(matrix_i, matrix_j, val);
}

R& Vector::element(uint32 i)
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  return Matrix::element(matrix_i, matrix_j);
}

const R& Vector::element(uint32 i) const
{
  uint32 matrix_i, matrix_j;
  matrixIndices(i, matrix_i, matrix_j);

  return Matrix::element(matrix_i, matrix_j);
}

void Vector::dim(uint32& n) const
{
  uint32 matrix_m, matrix_n;
  Matrix::dim(matrix_m, matrix_n);

  n = m_col ? matrix_m : matrix_n;
}

const uint32& Vector::dim() const
{ return m_col ? m_rows : m_cols; }

R Vector::sum() const
{
  R _sum = 0;
  uint32 n = dim();
  for (uint32 i = 1; i <= n; ++i)
    _sum += element(i);
  return _sum;
}

void Vector::matrixIndices(uint32 i, uint32& m_i, uint32& m_j) const
{
  m_i = m_col ? i : 1;
  m_j = m_col ? 1 : i;
}

std::ostream& operator<<(std::ostream& out_stream, const Matrix& matrix)
{
  uint32 rows = matrix.rows(), 
         cols = matrix.cols();
  for (uint32 i = 1; i <= rows; ++i) {
    for (uint32 j = 1; j <= cols; ++j)
      out_stream << "\t" << matrix.element(i, j);
    out_stream << std::endl;
  }

  return out_stream;
}

std::ostream& operator<<(std::ostream& out_stream, const Vector& vector)
{
  return operator<<(out_stream, *(Matrix*)(&vector));
}
