#pragma once

#include "defines.h"

#include <memory>
#include <ostream>

using MatrixElIndex = std::pair<uint32, uint32>;

class Matrix {
public:
  Matrix(uint32 m, uint32 n);
  Matrix(const Matrix&);
  ~Matrix();

  void get(uint32 i, uint32 j, R& val) const;
  void set(uint32 i, uint32 j, const R& val);

  R& element(uint32 i, uint32 j);
  const R& element(uint32 i, uint32 j) const;

  R& element(MatrixElIndex index);
  const R& element(MatrixElIndex index) const;

  void dim(uint32& m, uint32& n) const;
  uint32 rows() const;
  uint32 cols() const;

  friend std::ostream& operator<<(std::ostream& out_stream, const Matrix& matrix);

  static void fill(Matrix& M, const R& val);

protected:
  const uint32 m_cols,
               m_rows;

  R* const m_array;

private:
  size_t _INDEX(uint32 i, uint32 j) const;
  void _CHECK_RANGE(uint32 i, uint32 j) const;
  void _CHECK_DIM() const;

};

class Vector : protected Matrix {
public:
  Vector(uint32 n, bool col = true);
  Vector(const Vector&);

  void get(uint32 i, R& val) const;
  void set(uint32 i, const R& val);

  R& element(uint32 i);
  const R& element(uint32 i) const;

  void dim(uint32& n) const;
  const uint32& dim() const;

  R sum() const;

  friend std::ostream& operator<<(std::ostream& out_stream, const Vector& vector);

  operator Matrix&() { return *this; }

protected:
  void matrixIndices(uint32 i, uint32& m_i, uint32& m_j) const;

private:
  const bool m_col;

};

class VectorC : public Vector {
public:
  VectorC(uint32 n) : Vector(n, true) {}

};

class VectorR : public Vector {
public:
  VectorR(uint32 n) : Vector(n, false) {}

};

using MatrixSP = std::shared_ptr<Matrix>;
using VectorSP = std::shared_ptr<Vector>;
