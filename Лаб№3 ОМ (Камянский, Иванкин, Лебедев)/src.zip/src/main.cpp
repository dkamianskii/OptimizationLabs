#include "base/defines.h"
#include "base/matrix.h"

#include <iostream>
#include <cassert>
#include <iomanip>


uint32 appeal = 0;
uint32 steps = 0;
uint32 grad_steps = 0;
Vector global_x;
Vector global_g;

R f(R x)
{
  appeal += 1;
  return (pow(x,5) - exp(x)) + log(x + 10);
}

R dichotomy(R(*func)(R), const Segment& seg, const R& e)
{
  appeal = 0;
  steps = 0;
  Segment bound(seg);
  R sigma = e / 10;

  while (bound.second - bound.first > e) {
    steps += 1;
    R mid = (bound.first + bound.second) / 2,
      x = mid - sigma,
      y = mid + sigma;
    R F1 = func(x),
      F2 = func(y);

    if (F1 > F2)
      bound.first = x;
    else
      bound.second = y;

//    std::cout << "x_n" << x << std::endl;
//    std::cout << "y_n" << y << std::endl;
//    std::cout << std::endl;

  }

  return (bound.first + bound.second) / 2;
}

R goldenRatio(R (*func)(R), const Segment& seg, const R& e)
{
  appeal = 0;
  steps = 0;
  R alpha_mult = 2 / (3 + std::sqrt(5)),
    betta_mult = 2 / (1 + std::sqrt(5));

  Segment bound({ seg.first, seg.second });
  R alpha = R_NAN(), 
    betta = R_NAN();
  R f_alpha = R_NAN(), 
    f_betta = R_NAN();
  R d = bound.second - bound.first;

  while (d > e) {
    steps += 1;

    // �������� ������ ��� �������������
    if (std::isnan(alpha)) {
      alpha = bound.first + alpha_mult * (bound.second - bound.first);
      f_alpha = func(alpha);
    }

    // �������� ������ ��� �������������
    if (std::isnan(betta)) {
      betta = bound.first + betta_mult * (bound.second - bound.first);
      f_betta = func(betta);
    }

    if (f_alpha > f_betta) {
      bound.first = alpha;

      alpha = betta;
      f_alpha = f_betta;

      // ���������� �����������
      betta = R_NAN();
    }
    else {
      bound.second = betta;

      betta = alpha;
      f_betta = f_alpha;

      // ���������� �����������
      alpha = R_NAN();
    }

    d *= betta_mult;
  }

  return std::isnan(alpha) ? betta : alpha;
}

void input(std::pair<R, R>& seg, R& e)
{
  std::cout << "Input [a b]: ";
  std::cin >> seg.first >> seg.second;

  std::cout << "Input epsilon: ";
  std::cin >> e;

  std::cout << std::endl;
}

int main()
{
  int execResult = 0;
  std::cout.precision(6);

  do {
    bool quit = false;

    std::cout << "1. goldenRatio" << std::endl;
    std::cout << "2. dichotomy" << std::endl;
    std::cout << std::endl;
    std::cout << "q. Quit" << std::endl;

    char menu;
    std::cout << "Choose variant: ";
    std::cin >> menu;

    Segment seg;
    R e;
    R x_min = 0;

    switch (menu) {
    case '1':
      input(seg, e);
      x_min = goldenRatio(&f, seg, e);
      break;
    case '2':
      input(seg, e);
      x_min = dichotomy(&f, seg, e);
      break;
    case 'q':
      quit = true;
      break;
    default:
      std::cout << "Invalid variant" << std::endl;
      break;
    }
    if (quit) break;

    std::cout << "Appeal to f(x): " << appeal << std::endl;
    std::cout << "Steps: " << steps << std::endl;
    std::cout << "min f([" << seg.first << ", " << seg.second << "]) = " 
                       "f(" << x_min << ") = "<< f(x_min) << std::endl;
    std::cout << std::endl << std::endl;

  } while (true);

  return execResult;
}