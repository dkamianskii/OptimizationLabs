#pragma once

#include "defines.h"

#include <memory>
#include <ostream>

using MatrixElIndex = std::pair<uint32, uint32>;

class Matrix;
class Vector;

using MatrixSP = std::shared_ptr<Matrix>;
using VectorSP = std::shared_ptr<Vector>;

class Matrix {
public:
  Matrix(uint32 m, uint32 n);
  Matrix(const MatrixElIndex& size);
  Matrix(const Matrix&);
  ~Matrix();

  void get(uint32 i, uint32 j, R& val) const;
  void set(uint32 i, uint32 j, const R& val);

  R& element(uint32 i, uint32 j);
  const R& element(uint32 i, uint32 j) const;
  R& element(MatrixElIndex index);
  const R& element(MatrixElIndex index) const;

  void dim(uint32& m, uint32& n) const;
  void dim(MatrixElIndex&) const;
  uint32 rows() const;
  uint32 cols() const;

  static void fill(Matrix& M, const R& val);

public:
  friend Matrix operator*(const R&, const Matrix&);
  friend Matrix operator*(const Matrix&, const R&);

  friend Matrix operator+(const Matrix&, const Matrix&);
  friend Matrix operator-(const Matrix&, const Matrix&);
  friend Matrix operator*(const Matrix&, const Matrix&);

  Matrix T() const;
  Matrix Inverse() const;

  Matrix operator=(const Matrix&);

public:
  operator Vector() const;
  operator VectorSP() const;
  operator R() const;

public:
  friend std::ostream& operator<<(std::ostream& out_stream, const Matrix& matrix);

public:
  static Matrix E(uint32 n);

  bool isDegenerate() const;

  Vector getRow(uint32 i) const;
  Vector getCol(uint32 j) const;
  void append(const Vector&);

protected:
  uint32 m_cols,
         m_rows;

  R* m_array;

private:
  size_t _INDEX(uint32 i, uint32 j) const;
  void _CHECK_RANGE(uint32 i, uint32 j) const;
  void _CHECK_DIM() const;

};

class Vector : public Matrix {
public:
  Vector();
  Vector(uint32 n, bool col = true);
  Vector(const Vector&);

  void get(uint32 i, R& val) const;
  void set(uint32 i, const R& val);

  R& element(uint32 i);
  const R& element(uint32 i) const;

  void dim(uint32& n) const;
  const uint32& dim() const;

  bool isCol() const;

  R sum() const;

public:
  Vector operator=(const Vector&);
  //friend Vector operator*(const R&, const Vector&);
  //friend Vector operator*(const Vector&, const R&);

public:
  operator Matrix&() { return *this; }
  operator R() const;

public:
  friend std::ostream& operator<<(std::ostream& out_stream, const Vector& vector);

protected:
  void matrixIndices(uint32 i, uint32& m_i, uint32& m_j) const;

protected:
  bool m_col;

private:
  using Matrix::get;
  using Matrix::set;
  using Matrix::element;
  using Matrix::dim;
  using Matrix::rows;
  using Matrix::cols;

};

class VectorC : public Vector {
public:
  VectorC(uint32 n) : Vector(n, true) {}
  VectorC(const Vector& that) : Vector(that) { m_col = true; }

};

class VectorR : public Vector {
public:
  VectorR(uint32 n) : Vector(n, false) {}
  VectorR(const Vector& that) : Vector(that) { m_col = false; }

};
