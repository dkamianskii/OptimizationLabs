#pragma once

#include <exception>
#include <stdexcept>

#include <cmath>
#include <stdint.h>
#include <limits>
#include <utility>

#if defined(_DEBUG)
# include <iostream>
#endif

using R = double;
using Segment = std::pair<R, R>;
constexpr auto R_NAN() { return std::numeric_limits<R>::quiet_NaN(); }

using uint32 = uint32_t;
